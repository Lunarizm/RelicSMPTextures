Place your six PNG files in this folder with these exact names:

earth.png
air.png
chaos.png
fire.png
shadow.png
water.png

Recommended size: 16x16, 32x32, or 64x64.
