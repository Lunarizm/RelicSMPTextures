# RelicPack

This resource pack is preconfigured for RelicSMP element tokens using:

- `cobblestone` + `CustomModelData:1001` -> earth
- `feather` + `CustomModelData:1002` -> air
- `redstone` + `CustomModelData:1003` -> chaos
- `blaze_powder` + `CustomModelData:1004` -> fire
- `ender_eye` + `CustomModelData:1005` -> shadow
- `heart_of_the_sea` + `CustomModelData:1006` -> water

## 1) Add your PNG textures

Put these exact files in:

`assets/relicsmp/textures/item/elements/`

- `earth.png`
- `air.png`
- `chaos.png`
- `fire.png`
- `shadow.png`
- `water.png`

## 2) Zip correctly

Zip the *contents* of this folder (not the folder itself), so the zip root contains:

- `pack.mcmeta`
- `assets/`

## 3) Enable on server

Set your pack URL and SHA1 in `server.properties` and restart.

## Notes

- `pack.mcmeta` currently uses `pack_format: 34` (Minecraft 1.21 baseline).
- If your server runs a different major version and the pack is rejected, update `pack_format` to match that server version.
